#include "Account.h"
#include <cmath>
#include <iostream>
#include <utility>
using namespace std;
using namespace std::rel_ops;


AccountRecord::AccountRecord(const Date& m_date, const Account* m_account, double m_amount, double m_balance, const std::string& m_desc)
	: date(m_date), account(m_account), amount(m_amount), balance(m_balance), desc(m_desc) { }

void AccountRecord::show() const {
	date.show();
	cout << "\t#" << account->getId() << "\t" << amount << "\t" << balance << "\t" << desc << endl;
}


double Account::total = 0;
RecordMap Account::recordMap;
Account::Account(const Date& m_date, const std::string& m_id)
	: id(m_id), balance(0) {
	m_date.show();
	cout << "\t#" << id << " created" << endl;
}

void Account::record(const Date& m_date, double m_amount, const string& m_desc) {
	m_amount = floor(m_amount * 100 + 0.5) / 100;	
	balance += m_amount;
	total += m_amount;
	AccountRecord record(m_date, this, m_amount, balance, m_desc);
	recordMap.insert(make_pair(m_date, record));
	record.show();
}

void Account::show() const {
	cout << id << "\tBalance: " << balance;
}

void Account::error(const string& m_msg) const {
	cout << "Error(#" << id << "): " << m_msg << endl;
}

void Account::query(const Date& m_begin, const Date& m_end) {
	if (m_begin <= m_end) {
		RecordMap::iterator iter1 = recordMap.lower_bound(m_begin);
		RecordMap::iterator iter2 = recordMap.upper_bound(m_end);
		for (RecordMap::iterator iter = iter1; iter != iter2; ++iter)
			iter->second.show();
	}
}

SavingsAccount::SavingsAccount(const Date& date, const string& id, double rate)
	: Account(date, id), rate(rate), acc(date, 0) { }

void SavingsAccount::deposit(const Date& date, double amount, const string& desc) {
	record(date, amount, desc);
	acc.change(date, getBalance());
}

void SavingsAccount::withdraw(const Date& date, double amount, const string& desc) {
	if (amount > getBalance()) {
		error("not enough money");
	}
	else {
		record(date, -amount, desc);
		acc.change(date, getBalance());
	}
}

void SavingsAccount::settle(const Date& date) {
	if (date.getMonth() == 1) {
		double interest = acc.getSum(date) * rate
			/ (date - Date(date.getYear() - 1, 1, 1));
		if (interest != 0)
			record(date, interest, " interest");
		acc.reset(date, getBalance());
	}
}
CreditAccount::CreditAccount(const Date& date, const string& id, double credit, double rate, double fee)
	: Account(date, id), credit(credit), rate(rate), fee(fee), acc(date, 0) { }

void CreditAccount::deposit(const Date& date, double amount, const string& desc) {
	record(date, amount, desc);
	acc.change(date, getDebt());
}

void CreditAccount::withdraw(const Date& date, double amount, const string& desc) {
	if (amount - getBalance() > credit) {
		error("not enough credit");
	}
	else {
		record(date, -amount, desc);
		acc.change(date, getDebt());
	}
}

void CreditAccount::settle(const Date& date) {
	double interest = acc.getSum(date) * rate;
	if (interest != 0)
		record(date, interest, " interest");
	if (date.getMonth() == 1)
		record(date, -fee, " annual fee");
	acc.reset(date, getDebt());
}

void CreditAccount::show() const {
	Account::show();
	cout << "\tAvailable credit:" << getAvailableCredit();
}
