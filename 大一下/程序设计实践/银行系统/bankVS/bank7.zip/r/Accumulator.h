#ifndef __ACCUMULATOR_H__
#define __ACCUMULATOR_H__
#include "date.h"

class Accumulator {	
private:
	Date lastDate;	
	double value;	
	double sum;		
public:
	Accumulator(const Date& _date, double _value)
		: lastDate(_date), value(_value), sum(0) { }
	double getSum(const Date& _date) const {
		return sum + value * (_date - lastDate);
	}

	void change(const Date& _date, double _value) {
		sum = getSum(_date);
		lastDate = _date;
		value = _value;
	}
	void reset(const Date& _date, double _value) {
		lastDate = _date;
		value = _value;
		sum = 0;
	}
};

#endif //__ACCUMULATOR_H__
