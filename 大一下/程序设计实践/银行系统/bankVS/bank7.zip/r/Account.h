#pragma once
#ifndef __ACCOUNT_H__
#define __ACCOUNT_H__
#include "date.h"
#include "accumulator.h"
#include <string>
#include <map>
#include<exception>
using namespace std;
class Account;	
class AccountRecord {	
private:
	Date date;				
	const Account* account;	
	double amount;			
	double balance;			
	std::string desc;		
public:
	AccountRecord(const Date& m_date, const Account* m_account, double m_amount, double m_balance, const std::string& m_desc);
	void show() const;	
};

typedef std::multimap<Date, AccountRecord> RecordMap;

class Account {
private:
	std::string id;	
	double balance;	
	static double total; 
	static RecordMap recordMap;	
protected:
	Account(const Date& m_date, const std::string& m_id);
	void record(const Date& m_date, double m_amount, const std::string& m_desc);
	void error(const std::string& m_msg) const;
public:
	const std::string& getId() const { return id; }
	double getBalance() const { return balance; }
	static double getTotal() { return total; }
	virtual void deposit(const Date& m_date, double m_amount, const std::string& m_desc) = 0;	
	virtual void withdraw(const Date& m_date, double m_amount, const std::string& m_desc) = 0;
	virtual void settle(const Date& m_date) = 0;
	virtual void show() const;
	static void query(const Date& m_begin, const Date& m_end);
};

class SavingsAccount : public Account { 
private:
	Accumulator acc;	
	double rate;		
public:
	SavingsAccount(const Date& m_date, const std::string& m_id, double m_rate);
	double getRate() const { return rate; }
	virtual void deposit(const Date& m_date, double m_amount, const std::string& m_desc);
	virtual void withdraw(const Date& m_date, double m_amount, const std::string& m_desc);
	virtual void settle(const Date& m_date);
	
};

class CreditAccount : public Account { 
private:
	Accumulator acc;	
	double credit;		
	double rate;		
	double fee;			

	double getDebt() const {	
		double balance = getBalance();
		return (balance < 0 ? balance : 0);
	}
public:
	CreditAccount(const Date& m_date, const std::string& m_id, double m_credit, double m_rate, double m_fee);
	double getCredit() const { return credit; }
	double getRate() const { return rate; }
	double getFee() const { return fee; }
	double getAvailableCredit() const {	
		if (getBalance() < 0)
			return credit + getBalance();
		else
			return credit;
	}
	
	virtual void deposit(const Date& m_date, double m_amount, const std::string& m_desc);
	virtual void withdraw(const Date& m_date, double m_amount, const std::string& m_desc);
	virtual void settle(const Date& m_date);
	virtual void show() const;
};
class AccountException : public exception {
private:
	Account* account;
public:
	explicit AccountException(Account* account) : account(account) {};
	const char* what() const noexcept  {
		string e1 = "Not enough money in this account:";
		string e2 = account->getId();
		string e3 = to_string(account->getBalance());
		static string e4 = e1 + e2 + "\tbalance:" + e3;
		return e4.c_str();
	}
};
#endif //__ACCOUNT_H__
