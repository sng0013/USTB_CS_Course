#include "Account.h"
#include"date.h"
#include<stdexcept>
#include <iostream>
#include <vector>
#include <algorithm>
#include<fstream>
using namespace std;
struct deleter {
	template <class T> void operator () (T* p) { delete p; }
};
int main() {
	cout << "��ӭʹ������ϵͳ" << endl;
	bool is_reading = true;
	static bool only_show = false;
	Date date(2008, 11, 1);
	vector<Account*> accounts;
	char cmd;
	fstream commands;
	commands.open("commands.txt", ios_base::in | ios_base::out);
	if (!commands.is_open())
	{
		cout << "�޷����ļ�!" << endl;
		is_reading = false;
	}
	do {
		if (cin.fail()) return 0; 
		if (is_reading && commands.peek()==EOF)
		{
			commands.clear();
			is_reading = false;
			
		}
		if (!is_reading && !only_show) {
			cout << "(a)add account (d)deposit (w)withdraw (s)show (c)change day (n)next month (q)query (e)exit"
				<< endl;
			only_show = true;
		}
		if (!is_reading)
		{
			date.show();
			cout << "\tTotal: " << Account::getTotal() << "\tcommand> ";
		}
		char type;
		int index, day;
		double amount, credit, rate, fee;
		string id, desc;
		Account* account;
		Date date1{}, date2{};
		if (is_reading) commands >> cmd;
		else {
			cin >> cmd;
		}
		switch (cmd) {
		case 'a':
			if (is_reading)
				commands >> type >> id;
			else {
				try {
					cin >> type >> id;
					if (type == 's' || type == 'c') {
						commands << endl << cmd << " ";
						commands << type << " " << id << " ";
					}
					else throw runtime_error("Not a saving or credit account.");
				}
				catch (runtime_error& err) {
					cerr << err.what() << endl;
					break;
				}
			}
			if (type == 's') {
				if (is_reading) commands >> rate;
				else {
					cin >> rate;
					commands << rate;
				}
				account = new SavingsAccount(date, id, rate);
			}
			else {
				if (is_reading) commands >> credit >> rate >> fee;
				else {
					cin >> credit >> rate >> fee;
					commands << credit << " " << rate << " " << fee;
				}
				account = new CreditAccount(date, id, credit, rate, fee);
			}
			accounts.push_back(account);
			break;
		case 'd':
			try {
				if (is_reading) {
					commands >> index >> amount;
					getline(commands, desc);
				}
				else {
					cin >> index >> amount;
					getline(cin, desc);
					if (index < 0 || index >= accounts.size()) {
						throw runtime_error("The index you input is not exist.");
					}
				}
				accounts[index]->deposit(date, amount, desc);
			}
			catch (runtime_error& err) {
				cerr << err.what() << endl;
			}
			break;
		case 'w':
			try {
				if (is_reading) {
					commands >> index >> amount;
					getline(commands, desc);
				}
				else {
					cin >> index >> amount;
					getline(cin, desc);
					if (index < 0 || index >= accounts.size()) {
						throw runtime_error("The index you input is not exist.");
					}
				}
				accounts[index]->withdraw(date, amount, desc);
				
			}
			catch (AccountException& err) {
				cerr << err.what() << endl;
			}
			catch (runtime_error& err) {
				cerr << err.what() << endl;
			}
			break;
		case 's':
			for (size_t i = 0; i < accounts.size(); i++) {
				cout << "[" << i << "] ";
				accounts[i]->show();
				cout << endl;
			}
			break;

		case 'c':
			if (is_reading) commands >> day;
			else {
				cin >> day;
				commands << day;
			}
			if (day < date.getDay())
				cout << "You cannot specify a previous day";
			else if (day > date.getMaxDay())
				cout << "Invalid day" << endl;
			else
				date = Date(date.getYear(), date.getMonth(), day);
			
			break;

		case 'n':
			if (!is_reading)
				commands << endl << cmd << " ";
			if (date.getMonth() == 12)
				date = Date(date.getYear() + 1, 1, 1);
			else
				date = Date(date.getYear(), date.getMonth() + 1, 1);
			for (vector<Account*>::iterator iter = accounts.begin(); iter != accounts.end(); ++iter)
				(*iter)->settle(date);
			break;
		case 'q':
			try {
				date1 = Date::read();
				date2 = Date::read();
				Account::query(date1, date2);
			}
			catch (DateException& err) {
				cerr << err.what() << endl;
				if (cin.fail()) cin.clear();
			}
			break;
		default:
			cerr << "Not a right command." << endl;
			break;
		}
	} while (cmd != 'e');
	
	for_each(accounts.begin(), accounts.end(), deleter());
	commands.close();
	return 0;
}