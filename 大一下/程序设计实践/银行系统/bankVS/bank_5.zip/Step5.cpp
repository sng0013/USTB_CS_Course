﻿#include "account.h"
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// 定义一个删除器结构体，用于释放内存
struct deleter {
	template <class T> void operator () (T* p) { delete p; }
};

int main() {
	Date date(2008, 11, 1);	//起始日期
	vector<Account *> accounts;	//创建账户数组，用于存储账户信息，元素个数为0
	
	cout << "(a)add account (d)deposit (w)withdraw (s)show (c)change day (n)next month (q)query (e)exit" << endl;
	char cmd;

	do {
		//显示日期和总金额
		date.show();
		cout << "\tTotal: " << Account::getTotal() << "\tcommand> ";

		char type;//账户类型
		int index, day;//index序号 day日期的天数
		double amount, credit, rate, fee;//交易量amount 信用额度credit 利率rate 年费fee
		string id, desc;//desc用途
		Account* account;
		Date date1, date2;

		cin >> cmd;
		switch (cmd) {
		case 'a':	//增加账户
			cin >> type >> id;
			if (type == 's') {//创建储蓄类对象
				cin >> rate;
				account = new SavingsAccount(date, id, rate);
			}
			else {//创建信用类对象
				cin >> credit >> rate >> fee;
				account = new CreditAccount(date, id, credit, rate, fee);
			}
			accounts.push_back(account);
			break;
		case 'd':	//存入现金
			cin >> index >> amount;
			getline(cin, desc);
			accounts[index]->deposit(date, amount, desc);
			break;
		case 'w':	//取出现金
			cin >> index >> amount;
			getline(cin, desc);
			accounts[index]->withdraw(date, amount, desc);
			break;
		case 's':	//查询各账户信息
			for (size_t i = 0; i < accounts.size(); i++) {
				cout << "[" << i << "] ";
				accounts[i]->show();
				cout << endl;
			}
			break;
		case 'c':	//改变日期
			cin >> day;
			if (day < date.getDay())
				cout << "You cannot specify a previous day";
			else if (day > date.getMaxDay())
				cout << "Invalid day";
			else
				date = Date(date.getYear(), date.getMonth(), day);
			break;
		case 'n':	//进入下个月
			if (date.getMonth() == 12)
				date = Date(date.getYear() + 1, 1, 1);
			else
				date = Date(date.getYear(), date.getMonth() + 1, 1);
			for (vector<Account*>::iterator iter = accounts.begin(); iter != accounts.end(); ++iter)
				(*iter)->settle(date);
			break;
		case 'q':	//查询一段时间内的账目
			date1 = Date::read();
			date2 = Date::read();
			Account::query(date1, date2);
			break;
		}
	} while (cmd != 'e');

	//for_each函数被用来遍历accounts向量中的每个元素，并对每个元素调用deleter对象，从而释放所有账户对象的内存：
	for_each(accounts.begin(), accounts.end(), deleter());
	return 0;
}
