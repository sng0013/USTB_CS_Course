﻿//account.cpp
#include "account.h"
#include <cmath>
#include <iostream>
using namespace std;

double Account::total = 0;


//Account类的实现

//基类函数：供派生类调用的构造函数，显示该账户的创建
Account::Account(const Date &date, const string &id)
: id(id), balance(0) {
	date.show();
	cout << "\t#" << id << " created" << endl;
}

//基类函数：记账函数
void Account::record(const Date &date, double amount, const string &desc) {
	amount = floor(amount * 100 + 0.5) / 100;	//保留小数点后两位
	balance += amount;
	total += amount;
	date.show();
	cout << "\t#" << id << "\t" << amount << "\t" << balance << "\t" << desc << endl;
}

//基类函数：输出各个函数信息
void Account::show() const {
	cout << id << "\tBalance: " << balance;
}

//基类函数：报错
void Account::error(const string &msg) const {
	cout << "Error(#" << id << "): " << msg << endl;
}


//SavingsAccount类相关成员函数的实现

//派生类SavingsAccount：构造函数：初始化基类构造函数，初始化accumulator acc
SavingsAccount::SavingsAccount(const Date &date, const string &id, double rate)
: Account(date, id), rate(rate), acc(date, 0) { }

//派生类SavingsAccount：存钱
void SavingsAccount::deposit(const Date &date, double amount, const string &desc) {
	record(date, amount, desc);
	acc.change(date, getBalance());//使用计算器acc进行记录，实现之前accumulation的功能
}

//派生类Savings Account：取钱
void SavingsAccount::withdraw(const Date &date, double amount, const string &desc) {
	if (amount > getBalance())//取钱大于存钱数则报错
	{
		error("not enough money");
	}
	else //否则调用记账函数并使用acc计算器初步计算利息
	{
		record(date, -amount, desc);
		acc.change(date, getBalance());
	}
}

//结算利息，每年1月1日调用一次该函数
void SavingsAccount::settle(const Date &date) {
	double interest = acc.getSum(date) * rate	//计算年息
		/ date.distance(Date(date.getYear() - 1, 1, 1));
	if (interest != 0)
		record(date, interest, "interest");
	acc.reset(date, getBalance());
}


//CreditAccount类相关成员函数的实现

//派生类CreditAccount：构造函数：初始化基类构造函数，初始化accumulator acc
CreditAccount::CreditAccount(const Date& date, const string& id, double credit, double rate, double fee)
: Account(date, id), credit(credit), rate(rate), fee(fee), acc(date, 0) { }

//派生类CreditAccount：存钱
void CreditAccount::deposit(const Date &date, double amount, const string &desc) {
	record(date, amount, desc);
	acc.change(date, getDebt());//根据getDebt函数，假如balance>0,则不会进行利息计算；balance<0,则进行利息计算
}

//派生类CreditAccount：取钱
void CreditAccount::withdraw(const Date &date, double amount, const string &desc) {
	if (amount - getBalance() > credit) {
		error("not enough credit");
	}
	else {
		record(date, -amount, desc);
		acc.change(date, getDebt());
	}
}

//派生类CreditAccount：结算利息
void CreditAccount::settle(const Date &date) {
	double interest = acc.getSum(date) * rate;
	if (interest != 0)
		record(date, interest, "interest");
	if (date.getMonth() == 1)//如果又过了一年，需要提交年费
		record(date, -fee, "annual fee");
	acc.reset(date, getDebt());//对计算器进行重置
}

void CreditAccount::show() const {
	Account::show();
	cout << "\tAvailable credit:" << getAvailableCredit();
}
