#include "bullet.h"

Bullet::Bullet()
{

    m_Bullet.load(BULLET_PATH);
    m_X=GAME_WIDTH*0.5-m_Bullet.width()*0.5;
    m_Y=GAME_HEIGHT;
    m_Free=true;
    m_Speed=BULLET_RATE;
    m_Rect.setWidth(m_Bullet.width());
    m_Rect.setHeight(m_Bullet.height());
    m_Rect.moveTo(m_X,m_Y) ;
}

void Bullet::updatePosition()
{


    //空闲状态下的子弹,不需要计算坐标
    if (m_Free)
    {
        return;
    }

    //子弹向上移动
    m_Y -= m_Speed;
    m_Rect.moveTo(m_X,m_Y) ;

    //子弹位置 超出屏幕,重新变为空闲状态|
    if(m_Y <= -m_Rect.height ())
    {

        m_Free = true;
    }
}
