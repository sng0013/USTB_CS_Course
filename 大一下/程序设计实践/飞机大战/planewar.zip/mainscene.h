#ifndef MAINSCENE_H
#define MAINSCENE_H
#include "heroplane.h"
#include"map.h"
#include <QWidget>
#include <QTimer>
#include<QMouseEvent>
#include <QKeyEvent>
#include"enemy.h"
class MainScene : public QWidget
{
    Q_OBJECT

public:
    MainScene(QWidget *parent = nullptr);
    ~MainScene();
    void initScene();
    void playGame();
    void updatePosition();
    void paintEvent(QPaintEvent*);
    void mouseMoveEvent(QMouseEvent*);
    void keyPressEvent(QKeyEvent*);
    void enemyDis();
    void collisionDetection();
    void gameOver();
    QTimer m_Timer;
    Map m_map;
    HeroPlane m_hero;
    Enemy m_enemys[ENEMY_NUMER];
    int recorder;
    int m_score;
    // int m_currentScore;
    // int m_highestScore;
    // void clearScreen();
    // void resetGame();
};
#endif // MAINSCENE_H
