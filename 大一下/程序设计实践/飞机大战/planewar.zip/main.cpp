#include "mainscene.h"
#include <QResource>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //QResource::registerResource("./PLANE_res");
    //Q_INIT_RESOURCE(resources); // 初始化资源
    MainScene w;
    w.show();
    return a.exec();
}
