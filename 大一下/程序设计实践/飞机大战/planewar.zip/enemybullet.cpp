#include "enemybullet.h"
#include"config.h"

EnemyBullet::EnemyBullet()
{
    m_Bullet.load(ENEMY_BULLET_PATH); // 敌机子弹图片路径
    m_X = 0;
    m_Y = 0;
    m_Free = true;
    m_Speed = ENEMY_BULLET_SPEED; // 敌机子弹速度
    m_Rect.setWidth(m_Bullet.width());
    m_Rect.setHeight(m_Bullet.height());
    m_Rect.moveTo(m_X, m_Y);
}

void EnemyBullet::updatePosition()
{
    if (m_Free)
    {
        return;
    }

    m_Y += m_Speed; // 子弹向下移动
    m_Rect.moveTo(m_X, m_Y);

    if (m_Y >= GAME_HEIGHT)
    {
        m_Free = true;
    }
}

