#include "mainscene.h"
#include "config.h"
#include<QTimer>
#include<QPainter>
#include<QMouseEvent>
#include<enemy.h>
#include"heroplane.h"
#include <QRandomGenerator>
#include<QDebug>
MainScene::MainScene(QWidget *parent)
    : QWidget(parent)
{
    initScene();
    playGame();
}

MainScene::~MainScene() {}

void MainScene::initScene()
{
    setFixedSize(GAME_WIDTH,GAME_HEIGHT);
    setWindowTitle(GAME_TITLE);
    setWindowIcon(QIcon(GAME_ICON));
    m_Timer.setInterval(GAME_RATE);
    recorder=0;
    m_score = 0; // 初始化分
    // m_currentScore = 0;
    // m_highestScore = 0;
}

void MainScene::playGame()
{
    m_Timer.start();
    connect(&m_Timer,&QTimer::timeout,[=](){
        enemyDis();
        updatePosition();
        update();
        collisionDetection();
    }
    );
}

void MainScene::updatePosition()
{
    m_map.mapPosition();
    // temp_BUllet.m_Free=0;
    // temp_BUllet.updatePosition();
    //m_hero.shoot();
    //enemyDis();
    for(int i=0;i<BULLET_NUMBER;i++){
    if(m_hero.m_bullets[i].m_Free==0)
    {
        m_hero.m_bullets[i].updatePosition();
    }
    }
    for(int i=0;i<ENEMY_NUMER;i++)
    {
        if (!m_enemys[i].m_Free)
        {
            m_enemys[i].updatePosition();
            m_enemys[i].shoot();

            for (int j = 0; j < ENEMY_BULLET_NUMBER; j++)
            {
                if (!m_enemys[i].m_bullets[j].m_Free)
                {
                    m_enemys[i].m_bullets[j].updatePosition();
                }
            }
        }
    }
}

void MainScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(0,m_map.m_map1_posY,m_map.m_map1);
    painter.drawPixmap(0,m_map.m_map2_posY,m_map.m_map2);
    painter.drawPixmap(m_hero.m_X,m_hero.m_Y,m_hero.m_Plane);
    //painter.drawPixmap(temp_BUllet.m_X,temp_BUllet.m_Y,temp_BUllet.m_Bullet);
    for(int i=0;i<BULLET_NUMBER;i++){
        if(m_hero.m_bullets[i].m_Free==0){
        painter.drawPixmap(m_hero.m_bullets[i].m_X,m_hero.m_bullets[i].m_Y,m_hero.m_bullets[i].m_Bullet);
        }
    }
     painter.drawPixmap(m_enemys[0].m_X,m_enemys[0].m_Y,m_enemys[0].m_enemy);
    for(int i=0;i<ENEMY_NUMER;i++)
    {
        if(m_enemys[i].m_Free==0)
        {
            //qDebug() << "Drawing enemy at position:" << m_enemys[i].m_X << m_enemys[i].m_Y;
            painter.drawPixmap(m_enemys[i].m_X,m_enemys[i].m_Y,m_enemys[i].m_enemy);
            for (int j = 0; j < ENEMY_BULLET_NUMBER; j++)
            {
                if (!m_enemys[i].m_bullets[j].m_Free)
                {
                    painter.drawPixmap(m_enemys[i].m_bullets[j].m_X, m_enemys[i].m_bullets[j].m_Y, m_enemys[i].m_bullets[j].m_Bullet);
                }
            }
        }
    }

    // 画分数
    painter.drawText(10, 30, "Score: " + QString::number(m_score));
   //painter.drawText(10, 50, "Highest Score: " + QString::number(m_highestScore));

}

void MainScene::mouseMoveEvent(QMouseEvent *event)
{

    int x=event->x()-m_hero.m_Rect.width()*0.5;
    int y=event->y()-m_hero.m_Rect.height()*0.5;
    //边界检测
    if(x<=0)
    {
    x= 0;
    }
    if (x >= GAME_WIDTH - m_hero.m_Rect.width ())
    {

        x= GAME_WIDTH - m_hero.m_Rect.width();
    }
    if(y <= 0)
    {
          y= 0;
    }
    if(y >= GAME_HEIGHT - m_hero.m_Rect.height ())
    {
        y=GAME_HEIGHT - m_hero.m_Rect.height();
    }

    m_hero.setPosition(x,y);
}

void MainScene::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Space)
    {
        m_hero.shoot();
    }
}

void MainScene::enemyDis()
{
    recorder++;
    if(recorder<ENEMY_INTERVAL)
    {
        return;
    }
    recorder=0;
    for(int i=0;i<ENEMY_NUMER;i++)
    {
        if(m_enemys[i].m_Free)
        {
            //qDebug() << "Enemy " << i << " is being deployed";
            m_enemys[i].m_Free = false;
            m_enemys[i].m_X = QRandomGenerator::global()->bounded(GAME_WIDTH - m_enemys[i].m_Rect.width());
            m_enemys[i].m_Y = -m_enemys[i].m_Rect.height();
            //qDebug() << "Enemy position:" << m_enemys[i].m_X << m_enemys[i].m_Y;
            break;
        }
    }
}
void MainScene::collisionDetection()
{
for (int i = 0; i < ENEMY_NUMER; i++)
{
    if (m_enemys[i].m_Free)
    {
        continue;
    }

    for (int j = 0; j < BULLET_NUMBER; j++)
    {
        if (m_hero.m_bullets[j].m_Free)
        {
            continue;
        }

        if (m_enemys[i].m_Rect.intersects(m_hero.m_bullets[j].m_Rect))
        {
            m_enemys[i].m_Free = true;
            m_hero.m_bullets[j].m_Free = true;
            m_score++;
            if (m_score == 0)
            {
                gameOver();
            }
        }
    }

    for (int j = 0; j < ENEMY_BULLET_NUMBER; j++)
    {
        if (m_enemys[i].m_bullets[j].m_Free)
        {
            continue;
        }

        if (m_hero.m_Rect.intersects(m_enemys[i].m_bullets[j].m_Rect))
        {
            m_enemys[i].m_bullets[j].m_Free = true;
            m_score--;
            if (m_score == 0)
            {
                gameOver();
            }
        }
    }
}
}

void MainScene::gameOver()
{
    m_Timer.stop();
    // 显示游戏结束消息或其他处理
}
