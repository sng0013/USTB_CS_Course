#ifndef ENEMYBULLET_H
#define ENEMYBULLET_H
#include<QPixmap>
#include<QRect>
#include"config.h"
class EnemyBullet
{
public:
    EnemyBullet();

    // 更新子弹坐标
    void updatePosition();

    // 子弹资源对象
    QPixmap m_Bullet;

    // 子弹坐标
    int m_X;
    int m_Y;

    // 子弹移动速度
    int m_Speed;

    // 子弹是否闲置
    bool m_Free;

    // 子弹的矩形边框(用于碰撞检测)
    QRect m_Rect;
};

#endif // ENEMYBULLET_H
