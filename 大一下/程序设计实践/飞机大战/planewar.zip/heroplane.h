#ifndef HEROPLANE_H
#define HEROPLANE_H
#include<QPixmap>
#include"bullet.h"
class HeroPlane
{
public:
    HeroPlane();
    //发射子弹
    void shoot () ;
    //设置飞机位置
    void setPosition (int x, int y);

    QPixmap m_Plane;

    int m_X;
    int m_Y;

    //飞机的矩形边框
    QRect m_Rect;

    Bullet m_bullets[BULLET_NUMBER];
    int m_recorder;
};

#endif // HEROPLANE_H
