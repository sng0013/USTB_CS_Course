#include "enemy.h"
#include"config.h"
#include<QDebug>
#include"enemybullet.h"
Enemy::Enemy()
{
    //敌机资源加载
    m_enemy.load(ENEMY_PATH) ;
    //敌机资源加载
    // bool loadSuccess = m_enemy.load(ENEMY_PATH);
    // if (!loadSuccess) {
    //    qDebug() << "Failed to load enemy image!";
    // } else {
    //     qDebug() << "Enemy image loaded successfully!";
    // }
    //敌机位置
    m_X = 0;
    m_Y= 0;

    //敌机状态
    m_Free = true;

    //敌机速度
    m_Speed = ENEMY_SPEED;

    //(碰撞检测)
    m_Rect.setWidth(m_enemy.width());
    m_Rect.setHeight(m_enemy.height());
    m_Rect.moveTo(m_X,m_Y) ;
    m_recorder = 0;
}

void Enemy::updatePosition()
{
    if(m_Free)
    {
        return;
    }
    m_Y+=m_Speed;
    m_Rect.moveTo(m_X,m_Y);
    if(m_Y>=GAME_HEIGHT)
    {
        m_Free=true;
    }
    shoot();
}

void Enemy::shoot()
{
    m_recorder++;
    if (m_recorder < ENEMY_BULLET_INTERVAL)
    {
        return;
    }

    m_recorder = 0;
    for (int i = 0; i < ENEMY_BULLET_NUMBER; i++)
    {
        if (m_bullets[i].m_Free)
        {
            m_bullets[i].m_Free = false;
            m_bullets[i].m_X = m_X + m_Rect.width() * 0.5 - m_bullets[i].m_Rect.width() * 0.5;
            m_bullets[i].m_Y = m_Y + m_Rect.height();
            break;
        }
    }
}

