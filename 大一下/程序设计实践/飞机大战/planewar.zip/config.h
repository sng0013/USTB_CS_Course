#ifndef CONFIG_H
#define CONFIG_H
//游戏配置数据
#define GAME_WIDTH 512
#define GAME_HEIGHT 768
#define GAME_TITLE "PLANEWAR v1.0"
#define GAME_ICON ":/PLANE_res/gndw8g1w"
#define MAP_PATH ":/PLANE_res/2024-06-14 185305"
#define MAP_SCROLL_SPEED 2
#define GAME_RATE 10
#define HERO_PATH ":/PLANE_res/2024-06-14 2045101"
#define BULLET_RATE 5
#define BULLET_PATH ":/PLANE_res/4plmtead"
#define BULLET_NUMBER 30
#define BULLET_INTERVAL 20
#define ENEMY_PATH ":/PLANE_res/w4vmwih8" //敌机资源图片
#define ENEMY_SPEED 5 //敌机移动速度
#define ENEMY_NUMER 20//敌机总数量
#define ENEMY_INTERVAL 50 //敌机出场时问问隔
#define ENEMY_BULLET_PATH ":/PLANE_res/mdbx4uj7"
#define ENEMY_BULLET_SPEED 5
#define ENEMY_BULLET_NUMBER 30
#define ENEMY_BULLET_INTERVAL 50
#endif // CONFIG_H
