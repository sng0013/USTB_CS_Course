#include <iostream>
#include <conio.h>  
#include <windows.h>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <algorithm> 

using namespace std;

const int width = 55;  
const int height = 35;  
const int maxEnemies = 30;  
const char playerChar[5][10] = {
    " /=\\",  
    "<<*>>",
    "     ",
    "     ",
    "     "
};
const char enemyChar[3][6] = {
    "\\+/",  
    " |  ",
    "    "
};
const char bulletChar = '|';  

void gotoXY(int x, int y) {
    COORD pos = { (SHORT)x, (SHORT)y };  
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);  
    SetConsoleCursorPosition(hOut, pos);  
}

void HideCursor() {
    CONSOLE_CURSOR_INFO cursor_info = { 1, 0 };  
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
}

template<size_t H, size_t W>
class Entity {
public:
    int x, y;
    char shape[H][W];

    Entity(int x, int y, const char(&shape)[H][W]) : x(x), y(y) {
        for (size_t i = 0; i < H; ++i) {
            strcpy_s(this->shape[i], shape[i]);  
        }
    }

    void draw() const {
        for (size_t i = 0; i < H; ++i) {
            gotoXY(x, y + static_cast<int>(i));
            cout << shape[i];  
        }
    }

    void clear() const {
        for (size_t i = 0; i < H; ++i) {
            gotoXY(x, y + static_cast<int>(i));
            cout << string(W - 1, ' ');  
        }
    }

    int getHeight() const {
        return static_cast<int>(H);  
    }

    int getWidth() const {
        return static_cast<int>(W - 1); 
    }
};

class Bullet {
public:
    int x, y;
    bool active;
    bool isPlayer;

    Bullet(int x, int y, bool isPlayer = true) : x(x), y(y), active(true), isPlayer(isPlayer) {}

    void update() {
        if (active) {
            y += isPlayer ? -1 : 1; 
            if (y < 0 || y >= height) active = false;  
        }
    }

    void draw() const {
        if (active) {
            gotoXY(x, y);
            cout << bulletChar;  
        }
    }

    void clear() const {
        if (active) {
            gotoXY(x, y - (isPlayer ? 1 : -1));
            cout << ' '; 
        }
    }
};

class Game {
private:
    vector<Entity<3, 6>> enemies;  
    vector<Bullet> playerBullets;  
    vector<Bullet> enemyBullets; 
    Entity<5, 10> player;  
    int score;  
    int enemySpawnCounter;  
    int enemyBulletCounter;  

public:
    Game() : player(width / 2 - 4, height - 5, playerChar), score(0), enemySpawnCounter(0), enemyBulletCounter(0) {
        srand(static_cast<unsigned int>(time(0)));  
        for (int i = 0; i < maxEnemies / 5; ++i) {
            enemies.emplace_back(rand() % (width - 4), rand() % (height / 2), enemyChar);  
        }
    }

    void run() {
        HideCursor(); 
        while (true) {
            if (_kbhit()) {  // ����������
                char ch = _getch();
                if (ch == 'q' || ch == 'Q') {
                    system("cls");  
                    cout << "��Ϸ���������յ÷֣�" << score << endl;
                    break;
                }
                handleInput(ch);  
            }
            update();  
            draw();  
            Sleep(100);  
        }
    }

private:
    void handleInput(char ch) {
        player.clear(); 
        switch (ch) {
        case 'w': player.y = max(0, player.y - 1); break;  // ����
        case 's': player.y = min(height - player.getHeight(), player.y + 1); break;  // ����
        case 'a': player.x = max(0, player.x - 1); break;  // ����
        case 'd': player.x = min(width - player.getWidth(), player.x + 1); break;  // ����
        case ' ': playerBullets.emplace_back(player.x + 4, player.y - 1); break;  // �����ӵ�
        }
    }

    void update() {
        // ��������ӵ�
        for (auto& bullet : playerBullets) {
            bullet.clear();
            bullet.update();
        }
        playerBullets.erase(remove_if(playerBullets.begin(), playerBullets.end(), [](Bullet& b) { return !b.active; }), playerBullets.end());

        // ���µ����ӵ�
        for (auto& bullet : enemyBullets) {
            bullet.clear();
            bullet.update();
        }
        enemyBullets.erase(remove_if(enemyBullets.begin(), enemyBullets.end(), [](Bullet& b) { return !b.active; }), enemyBullets.end());

        // �������ӵ��������ײ
        for (auto it = enemies.begin(); it != enemies.end(); ) {
            bool hit = false;
            for (auto& bullet : playerBullets) {
                if (bullet.active && bullet.x >= it->x && bullet.x < it->x + it->getWidth() && bullet.y == it->y + 1) {
                    hit = true;
                    bullet.active = false;
                    score += 1;  
                    it->clear(); 
                    it = enemies.erase(it);  
                    break;
                }
            }
            if (!hit) {
                ++it;
            }
        }

        // �����µ���
        if (enemySpawnCounter++ > 10 && enemies.size() < maxEnemies) {
            enemies.emplace_back(rand() % (width - 4), 0, enemyChar);
            enemySpawnCounter = 0;
        }

        // ���˷����ӵ�
        if (enemyBulletCounter++ > 60) {
            for (auto& enemy : enemies) {
                enemyBullets.emplace_back(enemy.x + 2, enemy.y + 1, false);
            }
            enemyBulletCounter = 0;
        }

        // �������������ײ
        for (const auto& enemy : enemies) {
            if (player.x < enemy.x + enemy.getWidth() && player.x + player.getWidth() > enemy.x && player.y < enemy.y + enemy.getHeight() && player.y + player.getHeight() > enemy.y) {
                score -= 1;  
                if (score <= 0) {
                    system("cls");  
                    cout << "��Ϸ������" << endl;
                    break;
                }
            }
        }

        // ������������ӵ���ײ
        for (const auto& bullet : enemyBullets) {
            if (bullet.active && bullet.x >= player.x && bullet.x < player.x + player.getWidth() && bullet.y >= player.y && bullet.y < player.y + player.getHeight()) {
                score -= 1;  
                if (score <= 0) {
                    system("cls");  
                    cout << "��Ϸ������"<< endl;
                    exit(0);
                }
            }
        }
    }

    void draw() {
        system("cls"); 
        
        player.draw();
        
        for (const auto& enemy : enemies) {
            enemy.draw();
        }
        
        for (const auto& bullet : playerBullets) {
            bullet.draw();
        }
        
        for (const auto& bullet : enemyBullets) {
            bullet.draw();
        }
        
        gotoXY(0, 0);
        cout << "�÷�: " << score;
    }
};

int main() {
    char ch;
    cout << "�밴s��������Ϸ��";
    cin >> ch;
    if (ch == 's') {
        Game game;
        game.run();
    }
    return 0;
}

